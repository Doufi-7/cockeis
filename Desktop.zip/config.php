<?php
// Add your configuration settings here
$api = 'your_api_key';
$chatid = 'your_chat_id';
?>
